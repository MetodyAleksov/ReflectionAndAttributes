﻿using System;

namespace AuthorProblem
{
    [Author("Az")]
    [Author("Go6o")]
    public class StartUp
    {
        [Author("a sa de")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
